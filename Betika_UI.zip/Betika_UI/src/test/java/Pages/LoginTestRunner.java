package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class LoginTestRunner {

    private final WebDriver driver;

    private final By PhoneNumber = By.id("text");
    private final By PassWord = By.id("password");
    private final By loginButton = By.id("button account__payments__submit session__form__button login button button__secondary");


    public LoginTestRunner(WebDriver driver) {this.driver = driver;}

    public void enterUserNameAndPassword(String userName, String password) {

        driver.findElement(PhoneNumber).sendKeys(userName);
        driver.findElement(PassWord).sendKeys(password);
    }

    public void clickLoginButton() {

        driver.findElement(loginButton).click();
    }


}
