package Steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;

import static io.restassured.RestAssured.given;

public class APIStepDefinitions {

    public class ApiTestStepDefinitions {
        private String apiEndpoint;
        private Response response;

        @Given("^the API endpoint is \"https://fakerestapi.azurewebsites.net/api/v1/Users")
        public void the_api_endpoint_is(String apiEndpoint) {
            this.apiEndpoint = apiEndpoint;
            RestAssured.baseURI = apiEndpoint;
        }

        @When("^I send a GET request to the API endpoint$")
        public void i_send_a_GET_request_to_the_API_endpoint() {
            response = given().when().get("https://fakerestapi.azurewebsites.net/api/v1/Users");
        }

        @Then("^the API response code should be (\\d+)$")
        public void the_API_response_code_should_be(int expectedStatusCode) {
            int actualStatusCode = response.getStatusCode();
            Assert.assertEquals(expectedStatusCode, actualStatusCode);
        }

        @Then("^the API response should contain \"([^\"]*)\"$")
        public void the_API_response_should_contain(String expectedContent) {
            String responseString = response.getBody().asString();
            Assert.assertTrue(responseString.contains(expectedContent));
        }

        @Then("^the number of objects in the API response should be (\\d+)$")
        public void the_number_of_objects_in_the_API_response_should_be(int expectedNumObjects) {
            int actualNumObjects = response.jsonPath().getList("").size();
            Assert.assertEquals(expectedNumObjects, actualNumObjects);
        }
    }

}