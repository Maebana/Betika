package Steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginSteps {

    private WebDriver driver;

    @Given("^the user is on the login page$")
    public void navigateToLoginPage() {
        System.setProperty("web-driver.chrome.driver", "path/to/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://www.betika.com/en-ke/login");
    }

    @When("^the user enters (.+) and (.+)$")
    public void enterCredentials(String PhoneNumber, String password) {
        WebElement usernameInput = driver.findElement(By.id("text"));
        WebElement passwordInput = driver.findElement(By.id("password"));
        usernameInput.sendKeys(PhoneNumber);
        passwordInput.sendKeys(password);
    }

    @And("Clicks the login button")
    public void clicksTheLoginButton() {
        WebElement loginButton = driver.findElement(By.id("button account__payments__submit session__form__button login button button__secondary"));
        loginButton.click();
    }

    @Then("user is directed  to home page")
    public void user_is_directed_to_home_page() {


    }

    @When("the user places a bet")
    public void the_user_places_a_bet() {

    }


    @Then("the bet is successfully placed")
    public void the_bet_is_successfully_placed() {

    }

    @Then("the user receives a confirmation message")
    public void the_user_receives_a_confirmation_message() {

    }

}












